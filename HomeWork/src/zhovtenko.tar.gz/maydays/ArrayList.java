package maydays;

/**
 * Created by ioa on 17.05.17.
 */
public class ArrayList<T> implements List<T> {

    private int length;
    private T[] items;

    ArrayList(){
        length = 0;
        items = (T[]) new Object[length];
    }

    @Override
    public void add(T item) {
        length += 1;
        T[] old = items;
        items = (T[]) new Object[length];
        for(int i = 0; i < length-1; i++) {
            items[i] = old[i];
        }
        items[length-1] = item;
    }

    @Override
    public int size() {
        return length;
    }

    @Override
    public void remove(int index) {
        for(int i = index; i<length-1;i++)
            items[i] = items[i+1];
        length--;
    }

    @Override
    public T get(int index) {
        if (index<length)
            return items[index];
        else System.out.println("ERROR. MAX INDEX IS " + size());
        return null;
    }

    @Override
    public void insert(int index, T item) {
        length += 1;
        T[] old = items;
        items = (T[]) new Object[length];
        for (int i = 0; i < length - 1; i++) {
            items[i] = old[i];
        }
        for(int i = length-1; i > index ;i--) {
            items[i] = items[i-1];
        }
        items[index] = item;
    }
}

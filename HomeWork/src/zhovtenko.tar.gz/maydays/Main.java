package maydays;

/**
 * Created by ioa on 17.05.17.
 */
public class Main {
    public static void main(String[] args) {
        List<String> list = new ArrayList();
        List<Integer> list1 = new ArrayList();
        List<Object> list2 = new ArrayList();

        list.add("0f");
        list.add("2");
        list.add("bla");
        list.add("blabla");
        list.add("blablabla");

        for(int i = 0; i<10; i++){
            list1.add(i);
        }

        list2.add(list);
        list2.add(list1);
        list2.add("blabla");
        list2.add(0);


        list1.remove(0);
        list1.add(0);
        list1.add(6);
        list1.insert(3,0);
        list1.insert(6,0);
        list1.remove(6);

        list.insert(1,"zero");
        list.insert(4,"*");


        System.out.print("List <Integer>: ");
        for(int i = 0; i<list1.size(); i++){
            System.out.print(list1.get(i) + " ");
        }

        System.out.print("\nList <String>: ");
        for(int i = 0; i<list.size(); i++){
            System.out.print(list.get(i) + " ");
        }

        System.out.print("\nList <Object>: ");
        for(int i = 0; i<list2.size(); i++){
            System.out.print(list2.get(i) + " ");
        }
    }
}

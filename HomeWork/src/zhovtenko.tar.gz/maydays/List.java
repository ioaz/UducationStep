package maydays;

/**
 * Created by ioa on 17.05.17.
 */
public interface List<T> {
    void add(T item);
    int size();
    void remove(int index);
    T get(int index);
    void insert(int index, T item);
}

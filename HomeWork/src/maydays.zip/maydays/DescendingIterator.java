package maydays;

import java.util.Iterator;

/**
 * Created by ioa on 21.05.17.
 */
public interface DescendingIterator<E> {

    Iterator<E> descendingIterator();


}
